<?php 

$conn =mysqli_connect("localhost", "root", "", "login_system") or die("not connection");



?>
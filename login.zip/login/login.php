<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"/>
    <title>Login</title>
    <link rel="stylesheet" href="style.css"/>
</head>
<body>

    <form class="form" action="login_insert.php" method="post">
        <h1 class="login-title">Login</h1>

        <input type="text" class="login-input" name="username" placeholder="Username" autofocus="true" required="">

        <input type="password" class="login-input" name="password" placeholder="Password" required="">

        <input type="submit" value="Login" name="submit" class="login-button"/>

        <p class="link"><a href="registration.php">New Registration</a></p>
  </form>

</body>
</html>
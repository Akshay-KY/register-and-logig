<?php
    require('db.php');
 session_start();
    
    if (isset($_REQUEST['submit'])) {
      
        $username = stripslashes($_REQUEST['username']);
        // $username = mysqli_real_escape_string($conn, $username);
        // $email    = stripslashes($_REQUEST['email']);
        // $email    = mysqli_real_escape_string($conn, $email);
        $password = stripslashes($_REQUEST['password']);
        $email = stripslashes($_REQUEST['email']);
        
        $query    = "INSERT into `users` (username, password, email) VALUES ('$username', '".md5($password)."', '$email')";
        $result   = mysqli_query($conn, $query);

        if ($result) {
           $_session['username']=$username;
           header("location:login.php");

        } else {
            echo "<div class='form'>
                  <h3>Required fields are missing.</h3><br/>
                  <p class='link'>Click here to <a href='registration.php'>registration</a> again.</p>
                  </div>";
        }
    } 
?>
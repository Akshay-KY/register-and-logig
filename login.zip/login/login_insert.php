<?php 

require_once "db.php";
session_start();

if(isset($_POST['submit'])){

    $username=$_POST['username'];
    $password=md5($_POST['password']);

    $sql = mysqli_query($conn, "SELECT * from users WHERE username='$username' AND password='$password'");
       
    
    if(mysqli_num_rows($sql) > 0 ){
           $_session['username']=$username;
           header("location:registration.php");
    }
    else{
        echo "match";
    }
}


?>